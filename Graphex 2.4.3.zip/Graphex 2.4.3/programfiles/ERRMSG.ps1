[Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[Windows.Forms.MessageBox]::show("Your fucked Your fucked Your fucked Your fucked Your fucked Your fucked Your fucked", "windows")
[Windows.Forms.MessageBox]::show("I have a hitsquad already on their way, your going to die! (;", "The Hacker")
[Windows.Forms.MessageBox]::show("i have your adress!", "The Hacker")